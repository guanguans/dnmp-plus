<?php

namespace Predis {
    class Client {
        public function __call($commandId, $arguments) {}
    }
}
